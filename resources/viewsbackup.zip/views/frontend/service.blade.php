@extends('frontend.app')
@section('title','Business Planning')
@section('service_select','active')
@section('content')
@include('frontend.partials.breadcrumbs')
@include('frontend.partials.servicesection')
@include('frontend.partials.serviceslider')
@endsection
