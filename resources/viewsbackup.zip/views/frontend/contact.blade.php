@extends('frontend.app')
@section('title','Contact')
@section('contact_select','active')
@section('content')
@include('frontend.partials.breadcrumbs')
@include('frontend.partials.contact1')
@include('frontend.partials.contact2')
@endsection