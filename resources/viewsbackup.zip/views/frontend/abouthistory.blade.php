<!--about bg-history start--->
<section>
    <div class="bg-history">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="history1 welcome-part">
              <h1>
                CANZUK STAR is a professional consulting company
              </h1>
            </div>

          </div>
          <div class="col-md-6">
            <div class="history-1">
              <p>At vero eos et accusamus et iusto odio digni goiku ssimos ducimus qui blanditiis praese. Ntium voluum deleniti atque corrupti quos.</p>
            </div>
          </div>
          <div class="elementor-element elementor-element-861b1e7 elementor-widget elementor-widget-ct_history" data-id="861b1e7" data-element_type="widget" data-widget_type="ct_history.default">
            <div class="elementor-widget-container">
              <div class="ct-history1">
                <div class="ct-history--start">
                  Start </div>
                <div class="ct-history--holder">
                  <div class="ct-history--odd">
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          2nd Feb, 2018 </h3>
                        <span>Exhibition Planning &amp; Exhibition Management</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          21st Jul, 2018 </h3>
                        <span>Growth internationallyfirst half of the 2018s</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          19th Aug, 2018 </h3>
                        <span>The purpose of the business plan</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          2nd Jan, 2019 </h3>
                        <span>Focus business history on what matters to planning</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          22nd Sep, 2019 </h3>
                        <span>History to Unite and Inspire People</span>
                      </div>
                    </div>
                  </div>
                  <div class="ct-history--even">
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          12th Jan, 2018 </h3>
                        <span>Establishment of Constrio</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          8th Jul, 2018 </h3>
                        <span>Registered as a construction company</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          18th Aug, 2018 </h3>
                        <span>Construction bought the Greek company Delta</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          27th Sep, 2018 </h3>
                        <span>For lean business plans, operational plans, and strategic plans</span>
                      </div>
                    </div>
                    <div class="ct-history--item">
                      <div class="ct-history--meta">
                        <h3>
                          8th Jul, 2019 </h3>
                        <span>Award winner</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="ct-history--image">
                  <img class="rounded-circle" src="https://www.canzukstaroverseas.com/wp-content/uploads/2019/12/theme-15-150x150.jpg" width="150" height="150" alt="theme-15" title="theme-15" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
