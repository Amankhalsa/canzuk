<!--about section1 start--->
<section>
    <div class="container">
      <div class="holder">
        <div class="row align-items-center">
          <div class="col-md-9">
            <span class="title">Want to know more about us? </span>
            <span class="desc">Just download brochure...</span>
          </div>
          <div class="col-md-3">
             
            <div class="item-button1">
               <a href="{{asset('assets/about.pdf')}}" style="    background-color: #fff;
    padding: 14px 20px 14px 20px;
    border-radius: 4px;
    color:black;
    text-align: center;
    transition: all 0.5s;" download>
                <i class="fa-solid fa-cloud-arrow-down"></i>
                download brochure
             </a>
            </div>
             
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--about section1 end--->