<section>
    <div class="slider">
    <div class="container">
    <div class="row">
      <h1 class="slide-h">We have many reviews from our satisfied clients. </h1>
    <div class="swiper ddddd">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-07.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
          <h1 class="heading">kathleen smith</h1>
        <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-08 (1).jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
          <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-09.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
          <span class="span-about">Senior Director</span>

        </div>
        <div class="swiper-slide">
           <img class="rounded-circle" src="assets/images/testimonial-06.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
            <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-07.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
            <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-08 (1).jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
      <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-09.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
            <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-07.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
            <span class="span-about">Senior Director</span>
        </div>
        <div class="swiper-slide">
          <img class="rounded-circle" src="assets/images/testimonial-06.jpg" alt="">
          <p class="para">We also bring a strong interest in coaching and capability building, with an emphasis on emotional.</p>
            <h1 class="heading">kathleen smith</h1>
          <span class="span-about">Senior Director</span>
        </div>
      </div>
      <div class="swiper-button-next rounded-circle"></div>
      <div class="swiper-button-prev  rounded-circle"></div>
    </div>
    </div>
  </div>
</div>
  </section>