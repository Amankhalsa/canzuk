 <!--contact part start--->

 @php 
 $address = App\Models\Contact::first();
 @endphp
 <section>
    <div class="contact_info_section mt-5">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-12 gy-md-4">
            <div class="row justify-content-md-center align-items-md-center">
              <div class="col-auto">
                <div class="contact_location">
                  <img src="assets/images/location_icon.svg" alt="">
                </div>
              </div>
              <div class="col">
                <div class="contact_heading text-start text-lg-center">
                  <h3>Head Office Address:</h3>
                  <p>{{ $address->address}}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-12  gy-md-4">
            <div class="row justify-content-md-center align-items-md-center">
              <div class="col-auto">
                <div class="contact_location">
                  <img src="assets/images/location_icon.svg" alt="">
                </div>
              </div>
              <div class="col">
                <div class="contact_heading text-start text-lg-center">
                                   <h3>Head Office Address:</h3>
                  <p>{{ $address->address}}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-12 gy-md-4">
            <div class="row justify-content-md-center align-items-md-center">
              <div class="col-auto">
                <div class="contact_location">
                  <img src="assets/images/location_icon.svg" alt="">
                </div>
              </div>
              <div class="col">
                <div class="contact_heading text-start text-lg-center">
                               <h3>Head Office Address:</h3>
                  <p>{{ $address->address}}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>