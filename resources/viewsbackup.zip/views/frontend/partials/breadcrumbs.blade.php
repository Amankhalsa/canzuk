<!--about-home page start --->
<section>
    <div class="pagetitle">
      <div class="container">
        <div class="about_bg">
          <h1>@yield('title')</h1>
          <li><a href="{{url('')}}">Home - </a>
          </li>
          <li aria-current="">@yield('title')</li>
        </div>
      </div>
    </div>
    </div>
  </section>