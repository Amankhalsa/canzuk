<section>
    <div class="silder_footer_page">
     <div class="container">
       <div class="silder_footer_page">
         <div class="swiper mySwiper_two_there">
           <div class="swiper-wrapper">
             <div class="swiper-slide"><img src="assets/images/0.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/00.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/000.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/0000.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/0.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/00.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/000.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/0000.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/0.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/00.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/000.png" alt=""></div>
             <div class="swiper-slide"><img src="assets/images/0000.png" alt=""></div>
           </div>
           <div class="swiper-pagination"></div>
         </div>
       </div>
     </div>
      </div>
  </section>